# SimSo

SimSo is a scheduling simulator designed for the study of real-time scheduling algorithms.

- Project website: http://projects.laas.fr/simso/
- Documentation: http://projects.laas.fr/simso/doc/

You can find its graphical user interface here: https://github.com/MaximeCheramy/simso-gui

This is a free software available under the CeCILL license (GPL compatible).
