class WeatherType:
    CLEAR = 0
    CLOUD = 1
    RAIN = 2
