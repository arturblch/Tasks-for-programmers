class TerrainType:
    PLAIN = 0
    SWAMP = 1
    FOREST = 2
