class FacilityType:
    CONTROL_CENTER = 0
    VEHICLE_FACTORY = 1
